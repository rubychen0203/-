#!/usr/local/bin/python
# Connect to MariaDB Platform
import mysql.connector #mariadb

try:
	#連線DB
	conn = mysql.connector.connect(
		user="root",
		password="",
		host="localhost",
		port=3306,
		database="外送服務"
	)
	#建立執行SQL指令用之cursor, 設定傳回dictionary型態的查詢結果 [{'欄位名':值, ...}, ...]
	cursor=conn.cursor(dictionary=True)
except mysql.connector.Error as e: # mariadb.Error as e:
	print(e)
	print("Error connecting to DB")
	exit(1)


def add(data):
	sql="insert into 表格 (欄位,...) VALUES (%s,%s,...)"
	#param=('值',...)
	cursor.execute(sql,param)
	conn.commit()
	return
	
def delete(id):
	sql="delete from 表格 where 條件"
	cursor.execute(sql,(id,))
	conn.commit()
	return

def update(id,data):
	sql="update 表格 set 欄位=值,... where 條件"
	#param=('值',...)
	cursor.execute(sql,param)
	conn.commit()
	return
	
def getList():
	sql="select 欄位,... from 表格 where 條件;"
	#param=('值',...)
	cursor.execute(sql,param)
	return cursor.fetchall()

def getM_List():
	sql="select l_name name, l_price price from list where 1=1;"
	#param=('值',...)
	cursor.execute(sql)
	return cursor.fetchall()

def addtocar(name, price):
	SQL="INSERT INTO car(c_name, c_price) VALUES (%s,%s)"
	cursor.execute(SQL,(name, price,))
	conn.commit()
	return

def customers():#顧客
	sql="select id,user_id,name,email,phone,address from customers;"
	#param=('值',...) 
	cursor.execute(sql)
	return cursor.fetchall()

def delivery_persons():#外送小哥
	sql="select id,phone,user_id,name,current_order_id,earnings from delivery_persons;"
	#param=('值',...) 
	cursor.execute(sql)
	return cursor.fetchall()

def orders():
    sql = """
    SELECT 
        o.id, 
        o.customer_id, 
        r.name AS restaurant_name, 
        r.address AS restaurant_address, 
        b.phone AS buyer_phone,
        o.delivery_person_id, 
        o.order_status, 
        o.total_amount, 
        o.order_time, 
        o.delivery_time, 
        o.delivery_address, 
        o.payment_status 
    FROM 
        orders o
    JOIN 
        restaurants r 
    ON 
        o.restaurant_id = r.id
    JOIN 
        customers b 
    ON 
        o.customer_id = b.id
    WHERE 
        o.order_status IN ('待接單', '配送中');
    """
    cursor.execute(sql)
    return cursor.fetchall()




def menu():#菜單
	sql="select id,restaurant_id,item_name,price,description from menu;"
	#param=('值',...) 
	cursor.execute(sql)
	return cursor.fetchall()

def restaurants():#餐廳
	sql="select id,user_id,name,address,phone,account_balance from restaurants;"
	#param=('值',...) 
	cursor.execute(sql)
	return cursor.fetchall()

def reviews():#評價
	sql="select id,customer_id,restaurant_id,delivery_person_id,rating,comment,created_at from reviews;"
	#param=('值',...) 
	cursor.execute(sql)
	return cursor.fetchall()

def settlements():#平台結算
	sql="select id,restaurant_id,delivery_person_id,customer_id,amount,transaction_date from settlements;"
	#param=('值',...) 
	cursor.execute(sql)
	return cursor.fetchall()

def users():#使用者
	sql="select id,username,password,email,phone,role,created_at from users where role='delivery_person';"
	#param=('值',...) 
	cursor.execute(sql)
	return cursor.fetchall()

def delC_List(name):
	sql="DELETE FROM car WHERE c_name=%s"
	cursor.execute(sql,(name,))
	return