from flask import Flask, render_template, request, session, redirect
from functools import wraps
from dbUtils import delivery_persons, customers, orders, menu, restaurants, reviews, settlements, users
from dbUtils import conn, cursor  # 確保正確導入資料庫連線和游標

app = Flask(__name__, static_folder='static', static_url_path='/')
app.config['SECRET_KEY'] = '123TyU%^&'


def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        loginID = session.get('loginID')
        if not loginID:
            return redirect('/外賣登入.html')
        return f(*args, **kwargs)
    return wrapper


@app.route("/api/orders", methods=["GET"])
def get_orders():
    all_orders = orders()
    filtered_orders = [order for order in all_orders if order['order_status'] == '待接單']
    return {"data": filtered_orders}


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('外賣登入.html')

    user_id = request.form.get('ID', '').strip()
    user_password = request.form.get('PWD', '').strip()

    if not user_id or not user_password:
        return redirect('外賣登入.html')

    try:
        sql = "SELECT id, username, password FROM users WHERE username = %s"
        cursor.execute(sql, (user_id,))
        user = cursor.fetchone()

        if user and user['password'] == user_password:
            session['loginID'] = user['id']
            session['name'] = user['username']
            return redirect("/Myde")
    except Exception as e:
        print(f"登入時發生錯誤: {e}")

    session['loginID'] = False
    return redirect('外賣登入.html')


@app.route("/Myde")
@login_required
def Myde():
    owner_id = session.get('loginID')
    try:
        sql = "SELECT * FROM delivery_persons WHERE user_id = %s"
        cursor.execute(sql, (owner_id,))
        user_delivery_data = cursor.fetchall()
    except Exception as e:
        print(f"查詢外送員數據時發生錯誤: {e}")
        user_delivery_data = []

    owner_name = session.get('name')
    return render_template('我的外送.html', data=user_delivery_data, owner=owner_name)


@app.route("/delist")
def delist():
    all_orders = orders()
    filtered_orders = [order for order in all_orders if order['order_status'] == '待接單']
    return render_template('待送清單.html', data=filtered_orders)


@app.route("/mydelist")
def mydelist():
    login_id = session.get('loginID')
    zall_orders = orders()
    de_orders = [order for order in zall_orders if order['order_status'] == '配送中' and order['delivery_person_id'] == login_id]
    return render_template('我的接單.html', data=de_orders)


@app.route("/dde")
@login_required
def dde():
    delivery_person_id = session.get('loginID')
    try:
        sql_active = """
        SELECT o.id, o.total_amount, o.delivery_address, o.payment_status, 
               r.address AS restaurant_address, r.name AS restaurant_name, 
               b.phone AS customer_phone
        FROM orders o
        JOIN restaurants r ON o.restaurant_id = r.id
        JOIN customers b ON o.customer_id = b.id
        WHERE o.order_status = '配送中' AND o.delivery_person_id = %s
        LIMIT 1
        """
        cursor.execute(sql_active, (delivery_person_id,))
        active_order = cursor.fetchone()

        if active_order:
            return render_template('開始外送.html', data=[active_order])

        sql_waiting = """
        SELECT o.id, o.total_amount, o.delivery_address, o.payment_status, 
               r.address AS restaurant_address, r.name AS restaurant_name, 
               b.phone AS customer_phone
        FROM orders o
        JOIN restaurants r ON o.restaurant_id = r.id
        JOIN customers b ON o.customer_id = b.id
        WHERE o.order_status = '待接單'
        LIMIT 1
        """
        cursor.execute(sql_waiting)
        waiting_order = cursor.fetchone()

        if waiting_order:
            return render_template('開始外送.html', data=[waiting_order])
    except Exception as e:
        print(f"查詢訂單失敗: {e}")

    return "<script>alert('目前無訂單可處理！'); window.location.href='/delist';</script>"


@app.route("/setFinish", methods=["GET"])
@login_required
def setFinish():
    order_id = request.args.get("id")
    delivery_person_id = session.get('loginID')

    if not order_id or not delivery_person_id:
        return redirect("/delist")

    try:
        sql_check = "SELECT order_status FROM orders WHERE id = %s"
        cursor.execute(sql_check, (order_id,))
        order = cursor.fetchone()

        if not order or order['order_status'] != '待接單':
            return "<script>alert('接單失敗，此訂單已被接走！'); window.location.href='/delist';</script>"

        sql_update = """
        UPDATE orders
        SET order_status = %s, delivery_person_id = %s
        WHERE id = %s AND order_status = '待接單'
        """
        values = ("配送中", delivery_person_id, order_id)
        cursor.execute(sql_update, values)
        conn.commit()
    except Exception as e:
        print(f"接單失敗: {e}")
        conn.rollback()
        return redirect("/delist")

    return redirect("/mydelist")


@app.route("/deFinish", methods=["POST"])
@login_required
def deFinish():
    order_id = request.form.get("id")

    if not order_id:
        return redirect("/dde")

    try:
        sql = """
        UPDATE orders
        SET order_status = %s
        WHERE id = %s
        """
        values = ("已完成", order_id)
        cursor.execute(sql, values)
        conn.commit()
    except Exception as e:
        print(f"更新失敗: {e}")
        conn.rollback()
        return redirect("/dde")

    return redirect("/mydelist")


@app.route("/test/<string:name>/<int:id>")
def useParam(name, id):
    return f"got name={name}, id={id}"


@app.route("/edit")
def h1():
    dat = {
        "name": "大牛",
        "content": "內容說明文字"
    }
    return render_template('editform.html', data=dat)


@app.route("/update", methods=['GET', 'POST'])
def upd():
    name = request.form['name']
    cnt = request.form['content']
    html = f"update====> nnn={name}, cnt={cnt}"
    return html


@app.route("/list")
def h2():
    dat = [
        {"name": "大牛", "p": "超愛吃瓜"},
        {"name": "小李", "p": "怕榴槤"},
        {"name": "", "p": "ttttt"},
        {"name": "老謝", "p": "來者不拒"}
    ]
    return render_template('list.html', data=dat)


@app.route('/input', methods=['GET', 'POST'])
def userInput():
    form = request.form if request.method == 'POST' else request.args
    txt = form['txt']
    note = form['note']
    select = form['sel']
    msg = f"method: {request.method} txt:{txt} note:{note} sel: {select}"
    return msg


@app.route("/deliveryPersons")
def show_delivery_persons():
    data = delivery_persons()
    return render_template('delivery.html', data=data)


if __name__ == "__main__":
    app.run(debug=True)
