#!/usr/local/bin/python
# Connect to MariaDB Platform
import mysql.connector #mariadb
from datetime import datetime


try:
	#連線DB
	conn = mysql.connector.connect(
		user="root",
		password="",
		host="localhost",
		port=3306,
		database="test"
	)
	#建立執行SQL指令用之cursor, 設定傳回dictionary型態的查詢結果 [{'欄位名':值, ...}, ...]
	cursor=conn.cursor(dictionary=True)
except mysql.connector.Error as e: # mariadb.Error as e:
	print(e)
	print("Error connecting to DB")
	exit(1)


def add(data,user):
	sql="insert into goods (Owner,Name,Content,ReservePrice,Highest) VALUES (%s,%s,%s,%s,%s)"
	cursor.execute(sql,data)
	time= datetime.now()
	data_history = [cursor.lastrowid,user,data[3],time]
	sql_history = "insert into history (id,user,Bit,Time) VALUES (%s,%s,%s,%s)"
	cursor.execute(sql_history, data_history)
	conn.commit()
	
	return
	
def delete(id):
	sql = "DELETE FROM goods WHERE id = %s"
	cursor.execute(sql,(id,))
	
	sql_history ="DELETE FROM history WHERE id = %s"
	cursor.execute(sql_history, (id,))
	conn.commit()
	return

def update(data,user):
	sql="update goods set Name=%s,Content=%s,ReservePrice=%s,Highest=%s where id=%s"
	#param=('值',...)
	cursor.execute(sql,data)
	time= datetime.now()
	data_history = [data[4],user,data[3],time]
	sql_history = "insert into history (id,user,Bit,Time) VALUES (%s,%s,%s,%s)"
	cursor.execute(sql_history,data_history)
	conn.commit()
	return
	
def getList(Owner=None):
    if Owner:
        # 有提供 Owner，則過濾查詢
        sql = "SELECT id, Owner, Name, Content, ReservePrice FROM goods WHERE Owner = %s;"
        cursor.execute(sql, (Owner,))
    else:
        # 如果沒有提供 Owner，則查詢所有記錄
        sql = "SELECT id, Owner, Name, Content, ReservePrice, Highest FROM goods;"
        cursor.execute(sql)
    
    results = cursor.fetchall()
    return results if results else []  # 如果沒有結果，返回空列表

def getHistory(id):
	print(id)
	sql = "SELECT id,user,Bit,Time FROM history WHERE id = %s;"
	cursor.execute(sql, (id,))
	return cursor.fetchall()

def updateBid(data,userID):
	sql="update goods set Highest=%s where id=%s"
	#param=('值',...)
	cursor.execute(sql,data)
	time = datetime.now()
	history_data=[data[1],userID,data[0],time]
	history_sql="insert into history (id,user,Bit,Time) VALUES (%s,%s,%s,%s)"
	cursor.execute(history_sql,history_data)
	conn.commit()
	return