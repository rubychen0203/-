from flask import Flask, render_template, request, session, redirect,url_for,flash
from functools import wraps
from dbUtils import getList,add,delete,update,updateBid,getHistory

# creates a Flask application, specify a static folder on /
app = Flask(__name__, static_folder='static',static_url_path='/')
#set a secret key to hash cookies
app.config['SECRET_KEY'] = '123TyU%^&'

#define a function wrapper to check login session
def login_required(f):
	@wraps(f)
	def wrapper(*args, **kwargs):
		loginID = session.get('loginID')
		if not loginID:
			return redirect('/0.html')
		return f(*args, **kwargs)
	return wrapper

#another way to check login session
def isLogin():
	return session.get('loginID')
	

@app.route("/")
#check login with decorator function
@login_required
def hello(): 
	return redirect(url_for('gl'))



@app.route("/test/<string:name>/<int:id>")
#取得網址作為參數
def useParam(name,id):
	#check login inside the function
	if not isLogin():
		return redirect('/loginPage.html')
	return f"got name={name}, id={id} "

@app.route("/edit", methods=['POST'])
#使用server side render: template 樣板
def goEditpage():	
	form =request.form
	dat={
        "id": form['id'],
        "Name": form['Name'],
        "Content": form['Content'],  # 修正：使用 form['Content']
        "ReservePrice": form['ReservePrice']  # 修正：使用 form['ReservePrice']
	}
	#editform.html 存在於 templates目錄下, 將dat 作為參數送進 editform.html, 名稱為 data
	return render_template('editform.html', data=dat)


@app.route('/input', methods=['GET', 'POST'])
def userInput():
	if request.method == 'POST':
		form =request.form
	else:
		form= request.args

	txt = form['txt']  # pass the form field name as key
	note =form['note']
	select = form['sel']
	msg=f"method: {request.method} txt:{txt} note:{note} sel: {select}"
	return msg

@app.route("/list")
#使用server side render: template 樣板
def gl():
	dat=getList()
	return render_template('home.html', data=dat)

@app.route("/EveryoneList")
#使用server side render: template 樣板
def al():
	dat=getList()
	return render_template('allgoods.html', data=dat)

#handles login request
@app.route('/login', methods=['POST'])
def login():
	form =request.form
	id = form['ID']
	pwd =form['PWD']
	#validate id/pwd
	if id=='karlafay' and pwd=='123':
		session['loginID']=id
		return redirect(url_for('gl'))
	
	elif id=='shidoshi' and pwd=='321':
		session['loginID']=id
		return redirect(url_for('gl'))

	else:
		session['loginID']=False
		return redirect("/0.html")
	
@app.route('/logout',methods=['POST'])
def logout():
    # 清除會話中的 loginID
    session.pop('loginID', None)  # 刪除 loginID
    return redirect('/0.html') 

@app.route("/add",methods=['POST'])
#使用server side render: template 樣板
def addgoods():
	form =request.form
	data = (session['loginID'],form['Name'], form['Content'], form['ReservePrice'], form['ReservePrice'])
	add(data,session.get('loginID'))
	return redirect(url_for('gl'))

@app.route("/delete",methods=['POST'])
#使用server side render: template 樣板
def degoods():
	form = request.form
	id = form['id']  # 获取 ID
	delete(id)
	return redirect(url_for('gl'))

@app.route('/update', methods=['POST'])
def goupDB():
	form =request.form
	id = form.get('id')
	data = (form['Name'], form['Content'], form['ReservePrice'],form['ReservePrice'],id)
	update(data,session.get('loginID'))
	return redirect(url_for('gl'))

@app.route('/bid', methods=['POST'])
def bid():
	Highest = request.form.get('Highest', 0)  # 默认值为 0
	ReservePrice = request.form.get('ReservePrice', 0)  # 默认值为 0
	bid = request.form.get('bid', '')  # 获取出价，默认值为 ''
	id = int(request.form['id'])  # 拍卖项目 ID
    # 检查出价条件
	if (Highest is not None and bid <= Highest) or (Highest is None and bid <= ReservePrice):
		flash("出價必須高於現有價格或底價！", "error")  # 显示错误信息
		return redirect(url_for('al'))  # 重定向到拍卖页面或其他页面

	else:    # 如果出价有效，更新现有价格
		updateBid([bid, id],session.get('loginID'))
		return redirect(url_for('al'))
	
@app.route('/history', methods=['POST'])
def bidhistory():
	id = int(request.form['id']) # 拍卖项目 ID
	print(id)
	dat=getHistory(id)
	return render_template('historyPage.html',data=dat)