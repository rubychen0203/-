from flask import Blueprint, render_template, request, redirect, url_for, flash
from app.models import db, Menu, Order

restaurant_bp = Blueprint('restaurant', __name__, url_prefix='/restaurant')

# 商家儀表板
@restaurant_bp.route('/dashboard', methods=['GET'])
def dashboard():
    menu_count = Menu.query.count()
    order_count = Order.query.count()
    return render_template('restaurant/dashboard.html', menu_count=menu_count, order_count=order_count)

# 查看菜單
@restaurant_bp.route('/menu', methods=['GET'])
def view_menu():
    menu_items = Menu.query.all()
    return render_template('restaurant/menu.html', menu_items=menu_items)

# 編輯菜單
@restaurant_bp.route('/menu/edit', methods=['GET', 'POST'])
def edit_menu():
    if request.method == 'POST':
        item_name = request.form['item_name']
        price = float(request.form['price'])
        description = request.form['description']
        available = True if request.form['available'] == 'yes' else False

        new_item = Menu(
            restaurant_id=1,  # 假設目前只有一間餐廳
            item_name=item_name,
            price=price,
            description=description,
            available=available
        )
        db.session.add(new_item)
        db.session.commit()
        flash('菜品已成功新增', 'success')
        return redirect(url_for('restaurant.view_menu'))

    return render_template('restaurant/menu_edit.html')

# 刪除菜單項目
@restaurant_bp.route('/menu/delete/<int:item_id>', methods=['POST'])
def delete_menu_item(item_id):
    item = Menu.query.get_or_404(item_id)
    db.session.delete(item)
    db.session.commit()
    flash('菜品已成功刪除', 'success')
    return redirect(url_for('restaurant.view_menu'))

# 查看訂單狀態
@restaurant_bp.route('/orders', methods=['GET'])
def view_orders():
    orders = Order.query.all()
    return render_template('restaurant/order_status.html', orders=orders)

@restaurant_bp.route('/login', methods=['GET'])
def login_page():
    return render_template('login.html')

