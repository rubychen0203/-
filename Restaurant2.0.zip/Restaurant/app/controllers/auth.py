from flask import Blueprint, request, render_template, redirect, url_for, flash
from app.models import db, User, UserRoleEnum

auth_bp = Blueprint('auth', __name__, url_prefix='/auth')

# 登入檢測路由
@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # 從資料庫中查詢用戶
        user = User.query.filter_by(username=username).first()

        # 驗證密碼
        if user and user.password == password:
            flash('登入成功！', 'success')
            # 根據角色導向不同頁面
            if user.role == UserRoleEnum.ADMIN:
                return redirect(url_for('admin.dashboard'))
            elif user.role == UserRoleEnum.RESTAURANT:
                return redirect(url_for('restaurant.dashboard'))
            elif user.role == UserRoleEnum.CUSTOMER:
                return redirect(url_for('customer.home'))
            elif user.role == UserRoleEnum.DELIVERY_PERSON:
                return redirect(url_for('delivery.dashboard'))
        else:
            flash('用戶名或密碼錯誤！', 'danger')

    return render_template('auth/login.html')

# 測試資料初始化
def insert_test_data(app):
    with app.app_context():  # 確保 Flask 有正確的應用上下文
        # 檢查是否已存在測試帳號
        if not User.query.filter_by(username='test_user').first():
            test_user = User(
                username='test_user',
                password='123456',  # 測試用途，不加密
                email='test_user@example.com',
                phone='123456789',
                role=UserRoleEnum.CUSTOMER,
            )

            db.session.add(test_user)
            db.session.commit()
            print("測試帳號已成功新增！")
        else:
            print("測試帳號已存在，未新增。")
