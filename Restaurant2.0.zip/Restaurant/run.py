from flask import Flask
from app import db, create_app  # 從 app 導入 db 和 create_app
from app.controllers.restaurant import restaurant_bp  # 引入商家 Blueprint
from app.controllers.auth import insert_test_data  # 引入測試數據插入函數

app = create_app()

# 確保在應用上下文中創建資料表
with app.app_context():  # 確保執行操作時，處於應用上下文
    db.create_all()  # 創建所有資料表格（如果尚未創建）
    # 可以插入測試數據（如果需要）
    # insert_test_data(app)

# 啟動應用
app.run(debug=True)